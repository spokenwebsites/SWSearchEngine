# README


* Ruby version used: 2.7.6 
* System dependencies: Please find all the Blacklight Dependencies. 
Along with blacklight dependencies this application also requires Traject for indexing the data. 
Traject version should be higher than 3.8.1

* Configuration


* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

Some Tips with Indexing
* After we create a core and index the data it is required to the paste the solr -> config directoy of blacklight to solr core conf. 
This make the indexed data in solr to be blacklight searchable.
* Always restart the instance the solr instance and re-index the data. I will help make sure the reindexing is done properly.
* After Indexing new rows into solr make sure to add the neccessary field name in managed-schema.xml or schema.xml is solr core files.
* 