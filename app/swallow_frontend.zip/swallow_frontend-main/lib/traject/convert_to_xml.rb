require 'json'
require "active_support/all"

#Code to Convert JSON to XML
class DescribeIndexer
  def perform_indexing
    puts "entered"
    file = File.read('/Users/varshinivankayalapati/Desktop/Projects/swallow_frontend/lib/traject/xml/export.json')
    my_xml = JSON.parse(file).to_xml(:root => :swallow_record)
    puts my_xml
    File.write("/Users/varshinivankayalapati/Desktop/Projects/swallow_frontend/lib/traject/xml/concordia.xml", my_xml)
    p
  end
end

b = DescribeIndexer.new
b.perform_indexing